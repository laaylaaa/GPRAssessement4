using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OrangeBox : MonoBehaviour
{
    // true or false for if object tis correct
    public bool orangeBoxDone;
    public GameObject correctColourPlease, boxDoor;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name == "OrangeBox")
        {
            orangeBoxDone = true;
            boxDoor.SetActive(true);
            Debug.Log("Orange Place Correct ");// for checking 
        }
        else if (collision.gameObject.CompareTag("Player"))
        {
            return; // do nothing 
        }
        else if (collision.gameObject.name != "OrangeBox")
        {
            if (correctColourPlease.activeSelf == false)
            {
                collision.transform.position = GameObject.Find("BoxRespawn").transform.position;// move the wrong box to the box respawn

                correctColourPlease.SetActive(true);
            }
            else
            {
                collision.transform.position = GameObject.Find("BoxRespawn").transform.position;// move the wrong box to the box respawn
                return;
            }
        }
    }
}
