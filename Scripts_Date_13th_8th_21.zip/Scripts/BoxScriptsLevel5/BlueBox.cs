using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlueBox : MonoBehaviour
{
    // true or false for if object tis correct
    public bool blueBoxDone;
    public GameObject correctColourPlease, boxDoor;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name == "BlueBox")
        {
            blueBoxDone = true;
            boxDoor.SetActive(true); 
            Debug.Log("Blue Place Correct ");// for checking 
        }
        else if (collision.gameObject.CompareTag("Player"))
        {
            return; // do nothing 
        }
        else if (collision.gameObject.name != "BlueBox")
        {
            if (correctColourPlease.activeSelf == false)
            {
                collision.transform.position = GameObject.Find("BoxRespawn").transform.position;// move the wrong box to the box respawn
                correctColourPlease.SetActive(true);
            }
            else
            {
                collision.transform.position = GameObject.Find("BoxRespawn").transform.position;// move the wrong box to the box respawn
                return;
            }
        }
    }
}
