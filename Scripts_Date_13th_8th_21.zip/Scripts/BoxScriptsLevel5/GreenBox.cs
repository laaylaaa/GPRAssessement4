using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GreenBox : MonoBehaviour
{
    // true or false for if object tis correct
    public bool greenBoxDone;
    public GameObject correctColourPlease, boxDoor;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name == "GreenBox")
        {
            greenBoxDone = true;
            boxDoor.SetActive(true);
            Debug.Log("Green Place Correct"); // for checking 
        }
        else if (collision.gameObject.CompareTag("Player"))
        {
            return; // do nothing 
        }
        else if (collision.gameObject.name != "GreenBox")
        {
            if (correctColourPlease.activeSelf == false)
            {
                collision.transform.position = GameObject.Find("BoxRespawn").transform.position;// move the wrong box to the box respawn
                correctColourPlease.SetActive(true);
            }
            else
            {
                collision.transform.position = GameObject.Find("BoxRespawn").transform.position; // move the wrong box to the box respawn
                return;
            }
        }
    }
}
