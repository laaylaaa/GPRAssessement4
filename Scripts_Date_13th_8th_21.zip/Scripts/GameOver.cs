using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement; 

public class GameOver : MonoBehaviour
{
    [SerializeField] private string loadLevel; 

    public GameObject gameOverPanel, doors, timerText;
    public Text timer;
    public bool level5, level6;
    bool startTimerAllowed; 

    public float timeValue = 270; 
     void Update()
    {
        if (level5 == true)
        {
            if (doors.activeSelf == true)
                DisplayTime(timeValue);
            else
                return;
        }

        if (level6 == true && startTimerAllowed)
        {
            DisplayTime(timeValue);
        }
        else
            DisplayTime(timeValue); 

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            startTimerAllowed = true; 
        }
    }

    void DisplayTime(float timeToDisplay)
    {

        timerText.gameObject.SetActive(true);

        if (timeValue > 0)
            timeValue -= Time.deltaTime; // takes away from timer 
        else{

            timeValue = 0; // sets to 0 
            gameOverPanel.SetActive(true); // displays game over panel 
            Time.timeScale = 0f; // sets time to stop time 
        }
   
        float minutes = Mathf.FloorToInt(timeToDisplay / 60); // calc minutes 
        float seconds = Mathf.FloorToInt(timeToDisplay % 60); // check how many full mintues, takes it away and returns whats left

        if(timeToDisplay < 0) // make sure time isnt less then 0, if so make sure it only displays 0 
            timeToDisplay = 0; 
        else if(timeToDisplay > 0)
            timeToDisplay += 1;

        timer.text = "Time Left " + string.Format("{0:00}:{1:00}", minutes, seconds); 
    }

    public void LoadLevel()
    {
        SceneManager.LoadScene(loadLevel);
        Time.timeScale = 1f; // sets time to normal time 
        gameOverPanel.SetActive(false); // disables pause panel 
        timeValue += 90;
    }
}
