using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ChangeSceneTrigger : MonoBehaviour
{

    [SerializeField] private string loadLevel;

    //public Animator anim;


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            //anim.SetBool("Fade", true);
            SceneManager.LoadScene(loadLevel);
        }
    }

}
