using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class ModePicker : MonoBehaviour
{

    public bool easyModeSelected, hardModeSelected = false;

    public Button hardButton, easyButton; 

    // Start is called before the first frame update
    void Start()
    {
        Button btn = hardButton.GetComponent<Button>();
        Button btn2 = easyButton.GetComponent<Button>();

        btn.onClick.AddListener(HardMode);
        btn2.onClick.AddListener(EasyMode);
    }

    void EasyMode()
    {
        easyModeSelected = true; 
        print("Easy Mode picked " + easyModeSelected);
    }

    void HardMode()
    {
        hardModeSelected = true;
        print("Hard Mode picked " + hardModeSelected);
    }

}
