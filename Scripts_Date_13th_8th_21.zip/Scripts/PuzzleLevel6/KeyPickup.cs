﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class KeyPickup : MonoBehaviour
{
    [SerializeField]
    private Text pickupText;

    private bool pickupAllowed;

    public bool keyPickedUp; 

    // Use this for initialisation
    private void Start()
    {
        pickupText.gameObject.SetActive(false);
    }

    //Update is called once per frame
    private void Update()
    {
        if (pickupAllowed && Input.GetKeyDown(KeyCode.E))
            PickUp(); 
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name.Equals("Player"))
        {
            pickupText.gameObject.SetActive(true);
            pickupAllowed = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.name.Equals("Player"))
        {
            pickupText.gameObject.SetActive(false);
            pickupAllowed = false;
        }
    }

    private void PickUp()
    {
        Destroy(gameObject);
        keyPickedUp = true; 
    }

}
