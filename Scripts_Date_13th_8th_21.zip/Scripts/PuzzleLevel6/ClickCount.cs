using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; 

public class ClickCount : MonoBehaviour
{

    public int count = 30;

    public Text text;
    public bool countAllowed;
    public GameObject gameOverPanel;

    public List<GameObject> boxes; 

     void Update(){

        text.text = "Moves: " + count;  

        if(countAllowed && Input.GetKeyDown(KeyCode.Space))
        {
            Count();
        }

        if(count <= 0)
        {
            gameOverPanel.SetActive(true);
            Time.timeScale = 0f; // sets time to stop time 
        }
        else
        {
            Time.timeScale = 1f; 
        }
     }

    private void OnTriggerEnter2D(Collider2D collision)
    {
       for(int i = 0; i < boxes.Count; i++)
        {
            if(collision.gameObject == boxes[i])
            {
                countAllowed = true;
            }
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        for (int i = 0; i < boxes.Count; i++)
        {
            if (collision.gameObject == boxes[i])
            {
                countAllowed = false;
            }
        }
    }

    void Count()
    {
        count -= 1;
    }

}
