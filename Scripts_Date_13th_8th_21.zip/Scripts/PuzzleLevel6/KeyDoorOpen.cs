using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyDoorOpen : MonoBehaviour
{

    public GameObject key; 

    KeyPickup keyPickup; 

    // Start is called before the first frame update
    void Start()
    {
        keyPickup = key.GetComponent<KeyPickup>(); 
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            if(keyPickup.keyPickedUp == true)
            {
                Destroy(gameObject); 
            }
        }
    }
}
