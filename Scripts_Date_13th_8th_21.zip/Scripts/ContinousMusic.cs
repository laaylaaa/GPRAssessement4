﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ContinousMusic : MonoBehaviour
{
    public AudioSource backgroundSound;
    
    private GameObject[] other;
    private bool NotFirst = false; 
    
    void Awake()
    {
        other = GameObject.FindGameObjectsWithTag("Music");

        // the foreach and if are used when player goes back to a scene which already 
        // has the continous music object and destroys it so we dont hear double music playing 
        foreach(GameObject oneOther in other){
            
            if(oneOther.scene.buildIndex == -1)
            {
                NotFirst = true; 
            }
            
        }

        if(NotFirst == true)
        {
            Destroy(gameObject); 
        }
    
        DontDestroyOnLoad(transform.gameObject);
    }

    void Update()
    {

        int buildIndex = SceneManager.GetActiveScene().buildIndex;

        if (buildIndex == 6 || buildIndex == 8) // levels 1 for easy and hard mode 
        {
                GameObject.FindGameObjectWithTag("Music").GetComponent<ContinousMusic>().StopMusic(); // stop the music since it starts playing its own, done so that the music pause button can work. 
                Destroy(gameObject); // makes sure it doesnt continue through the rest of the levels 
        }

        if (backgroundSound.isPlaying) return; 
        backgroundSound.Play();
    }

    public void StopMusic()
    {
        backgroundSound.Stop();
    }
}

