using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

// Players Death and Death Count 

public class PlayerDeath : MonoBehaviour
{

    [SerializeField] Transform Respawn; // transform for respawning
    public GameObject Player; // get player 

    public AudioSource deathSound; 

    public Text deathCount;
    private int count; 

    private void Start()
    {
        count = 0; 
        SetCountText();
        deathSound = GetComponent<AudioSource>(); // gets the AudioSource which is on Player
    }

     private void OnCollisionEnter2D(Collision2D collision)  
    {
        if (collision.transform.CompareTag("Kill"))
        {
            Player.transform.position = Respawn.position; // change players position to the respawns position 
            deathSound.Play(); // play the death sound when they die 
            count = count + 1; // adding one to the count
            SetCountText();
        }

    }

    void SetCountText()
    {
        deathCount.text = "Deaths: " + count.ToString(); // setting the text 
    }
}
