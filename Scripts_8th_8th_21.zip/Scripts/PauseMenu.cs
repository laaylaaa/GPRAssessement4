using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; 

public class PauseMenu : MonoBehaviour
{
    public static bool GameIsPaused = false;

    public GameObject pauseMenuUI; 

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape)) // if player presses the escape key 
        {
            if (GameIsPaused)
            {
                Resume();
            }
            else
            {
                Pause(); 
            }
        }
    }

    public void Resume()
    {
        pauseMenuUI.SetActive(false); // disables pause panel 
        Time.timeScale = 1f; // sets time to normal time 
        GameIsPaused = false; // tells code it isnt paused 
    }

    void Pause()
    {
        pauseMenuUI.SetActive(true); // enables pause panel
        Time.timeScale = 0f; // sets time to 0 to pause game time 
        GameIsPaused = true; // tells code that game is paused 
    }

    public void MainMenu()
    {
        SceneManager.LoadScene("MainMenu");
        Time.timeScale = 1f; // sets time to normal time 
        pauseMenuUI.SetActive(false); // disables pause panel 
    }
}
