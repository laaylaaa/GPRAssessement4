using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PinkBox : MonoBehaviour
{
    public bool pinkBoxDone;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name == "PinkBox")
        {
            pinkBoxDone = true;
            Debug.Log("Pink Place Correct ");
        }
        else if (collision.gameObject.name != "PinkBox")
        {
            collision.transform.position = GameObject.Find("BoxRespawn").transform.position;
        }
    }
}
