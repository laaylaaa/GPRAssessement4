using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OrangeBox : MonoBehaviour
{
    public bool orangeBoxDone;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name == "OrangeBox")
        {
            orangeBoxDone = true;
            Debug.Log("Orange Place Correct ");
        }
        else if (collision.gameObject.name != "OrangeBox")
        {
            collision.transform.position = GameObject.Find("BoxRespawn").transform.position;
        }
    }
}
