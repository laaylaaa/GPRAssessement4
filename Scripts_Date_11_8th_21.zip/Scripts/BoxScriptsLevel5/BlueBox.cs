using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlueBox : MonoBehaviour
{
    public bool blueBoxDone; 

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name == "BlueBox")
        {
            blueBoxDone = true; 
            Debug.Log("Blue Place Correct ");
        }
        else if (collision.gameObject.name != "BlueBox")
        {
            collision.transform.position = GameObject.Find("BoxRespawn").transform.position;
        }
    }
}
