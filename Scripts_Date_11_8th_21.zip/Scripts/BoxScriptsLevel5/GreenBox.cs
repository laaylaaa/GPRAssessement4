using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GreenBox : MonoBehaviour
{
    public bool greenBoxDone;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name == "GreenBox")
        {
            greenBoxDone = true;
            Debug.Log("Green Place Correct ");
        }
        else if (collision.gameObject.name != "GreenBox")
        {
            collision.transform.position = GameObject.Find("BoxRespawn").transform.position;
        }
    }
}
