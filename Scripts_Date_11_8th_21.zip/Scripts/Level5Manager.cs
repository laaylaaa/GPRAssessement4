using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level5Manager : MonoBehaviour
{

    //private BoxCollision boxCollision;
    private BlueBox blueBox;
    private GreenBox greenBox;
    private OrangeBox orangeBox;
    private PinkBox pinkBox;
    private YellowBox yellowBox;

    public GameObject door;

    private void Start()
    {
        blueBox = GetComponent<BlueBox>();
        greenBox = GetComponent<GreenBox>();
        orangeBox = GetComponent<OrangeBox>();
        pinkBox = GetComponent<PinkBox>();
        yellowBox = GetComponent<YellowBox>();

        correctBoxes(); 
    }

    public void correctBoxes()
    {
        if (blueBox.blueBoxDone == true && greenBox.greenBoxDone == true && orangeBox.orangeBoxDone == true && pinkBox.pinkBoxDone == true && yellowBox.yellowBoxDone == true) 
            door.SetActive(false);
    }
}
