//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//public class BoxCollision : MonoBehaviour
//{

//    private Level5Manager level5Manager; 

//    [SerializeField] Transform Respawn; // transform for respawning
//   //public GameObject OrangeBox, GreenBox, YellowBox, PinkBox, BlueBox; // get player 
//    public string boxName;
//    //public GameObject door; 
//    //public GameObject[] boxes = new GameObject[5];

//    //public GameObject correctBox; 

//    //public int correctBoxes = 0;

//    private void Start()
//    {
//        level5Manager = GetComponent<Level5Manager>();
//    }

//    private void OnTriggerEnter2D(Collider2D collision)
//    {
//        if(collision.gameObject.name == boxName)
//        {
//            GetComponent<Level5Manager>().AddToCount();
//            Debug.Log(boxName + " Place Correct " + level5Manager.correctBoxes);
//        }
//        else if(collision.gameObject.name != boxName)
//        {
//            collision.transform.position = GameObject.Find("BoxRespawn").transform.position;
//        }
//    }
//}
